from objects.library import Library


def highest_scan_capacity(library: Library) -> int:
    return library.scan_capacity * -1
